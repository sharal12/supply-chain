export const LOGIN = "LOGIN"
export const LOGOUT = "LOGOUT" 

//categories types
export const FETCH_CATEGORIES = "FETCH_CATEGORIES"
