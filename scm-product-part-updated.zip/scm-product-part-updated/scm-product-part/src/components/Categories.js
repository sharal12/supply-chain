// import React from 'react'

// const Sizes = ({selectedSizes, setSize}) =>  {

//      const sizes = ['XS', 'S', 'M', 'ML', 'L', 'XL', 'XXL'];
   
//     return (
//         <div className="sizes">
//             <h3>Sizes</h3>
//             <div className="size-list">
//                 {
//                     sizes.map((size, index) => {
//                         return (
//                             <button 
//                                 className={ "size" + (selectedSizes.includes(size) ? " selected-size" : "")}
//                                 key={index}
//                                 onClick={() => setSize(size)}
//                             >
//                                 {size}
//                             </button>
//                         )
//                     })
//                 }
//             </div>
//         </div>
//     )
// }

// export default Sizes;
import React from 'react'

const Categories = ({selectedCategories, setCategory}) =>  {

     const categories = ['TITAN', 'ROLEX', 'SONATA', 'ROADSTER', 'FOSSIL', 'CASIO', 'CITIZEN'];
   
    return (
        <div className="categories">
            <h3>Categories</h3>
            <div className="categories-list">
                {
                    categories.map((category, index) => {
                        return (
                            <button 
                                className={ "category" + (selectedCategories.includes(category) ? " selected-category" : " ")}
                                key={index}
                                onClick={() => setCategory(category)}
                            >
                                {category}
                            </button>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default Categories;
