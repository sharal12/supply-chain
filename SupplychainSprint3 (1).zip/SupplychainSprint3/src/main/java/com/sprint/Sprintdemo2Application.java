package com.sprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprintdemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sprintdemo2Application.class, args);
	}

}
