package com.sprint.service;

import java.util.HashMap;
import java.util.List;

import com.sprint.beans.Product;

public interface ProductService {

	public List<String> getProduct();

}
