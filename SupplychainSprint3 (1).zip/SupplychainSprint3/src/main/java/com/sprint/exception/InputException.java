package com.sprint.exception;

public class InputException extends RuntimeException
{
	public InputException(String msg)
	{
		super(msg);
	}


}

