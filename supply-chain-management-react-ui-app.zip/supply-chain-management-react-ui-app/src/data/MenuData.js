export const menuData=[
    {title:'Home', link: '/about'},
    {title:'Products', link:'/products'},
    {title:'Offers', link:'/offers'}


];

