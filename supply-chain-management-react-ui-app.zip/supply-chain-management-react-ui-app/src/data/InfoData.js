import ImageOne from '../images/ex1.jpg';
import ImageTwo from '../images/ex-3.jpg';

export const InfoData={
	heading: 'Explore our exclusive collection',
	paragraphOne: 
		'Lorem ipsum sit amet consectetur',
	paragraphTwo: 
		'Lorem ipsum sit amet consectetur',
	buttonlabel: 'View Products',
	image:ImageOne,
	reverse: false,
	delay: 100
};

export const InfoDataTwo={
	heading: 'New Designs',
	paragraphOne: 
        'Lorem ipsum sit amet consectetur.',
    paragraphTwo: 
        'bcjhabc',
		
	buttonlabel: 'View Products',
	image:ImageTwo,
	reverse: true,
	delay: 300
};