import ImageOne from '../images/watch-1.jpg'
import ImageTwo from '../images/watch-5.jpg'
import ImageThree from '../images/watch-6.jpg'
import ImageFour from '../images/watch-4.jpg'



export const SliderData= [
    {
        title:'Fossil',
        path: '/products',
        label: 'Shop Now',
        image: ImageOne,
        alt: 'watch'
    },
    {
        title:'Casio',
        path: '/products',
        label: 'Shop Now',
        image: ImageTwo,
        alt: 'watch'
    },
    {
        title:'Rolex',
        path: '/products',
        label: 'View Product',
        image: ImageThree,
        alt: 'watch'
    },
    {
        title:'Citizen',
        path: '/products',
        label: 'View Product',
        image: ImageFour,
        alt: 'watch'
    }

]