package com.project.foodx.constants;

public class Constant {

    public static final String API_SECRET_KEY = "kdjfhsfjhsdkfjhsd9879fiuerwieuh87987dkjfhsdkjfhsdkjfhksdjfhskdj3";



}
