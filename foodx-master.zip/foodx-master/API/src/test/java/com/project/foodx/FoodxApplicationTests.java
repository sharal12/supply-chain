package com.project.foodx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodxApplicationTests {

	@Test
	void contextLoads() {
	}

}
